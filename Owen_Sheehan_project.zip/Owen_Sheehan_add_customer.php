<! DOCTYPE HTML>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Owen_Sheehan_add_customer</title>
<body>
	<h1>Connecting to the metro_vision database.</h1>
 	<form action="Owen_Sheehan_add_customer.php" method="POST">
    	First Name:<input name = "fname" type = "text" required>
        Last Name:<input name = "sname" type = "text" required>
        Phone:<input name = "tel" type = "text" required>
        Year of Birth:<input name = "dob" type ="date" maxlenght="4" size="4" required>
        <input type="submit" value="Send">
        <input type="reset" value="reset">
 	</form>
</body>
</html>